<script src="<?php echo assets('dist/js/report/report_v2.js?v=1')?>"></script>
<script src="<?php echo assets('dist/js/'.$menu.'/'.$sub_menu.'.js?v=9')?>"></script>