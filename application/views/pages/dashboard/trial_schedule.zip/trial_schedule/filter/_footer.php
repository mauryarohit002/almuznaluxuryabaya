<button 
    type="button" 
    id="btn_search" 
    class="btn btn-md btn-secondary btn-block text-uppercase" 
    onclick="get_record(true)"
>search</button>
<button 
    type="button" 
    id="btn_reset" 
    class="btn btn-md btn-secondary btn-block text-uppercase m-0" 
    onclick="reset_filter()"
>reset</button>